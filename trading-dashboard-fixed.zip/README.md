# Buy Low, Sell High Trading Dashboard

This is a Streamlit dashboard that analyzes stock tickers using a simple RSI + SMA strategy with stop-loss and take-profit logic.